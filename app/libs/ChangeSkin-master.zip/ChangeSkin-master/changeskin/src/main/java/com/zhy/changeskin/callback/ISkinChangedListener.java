package com.zhy.changeskin.callback;

/**
 * Created by zhy on 15/9/22.
 */
public interface ISkinChangedListener
{
    void onSkinChanged();
}
